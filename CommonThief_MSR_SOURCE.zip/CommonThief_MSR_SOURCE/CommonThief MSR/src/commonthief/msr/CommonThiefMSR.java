/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package commonthief.msr;

/**
 *
 * @author Ampix0
 */
public class CommonThiefMSR {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       formgui.GUI s = new formgui.GUI();
       s.setVisible(true);
    }
}
